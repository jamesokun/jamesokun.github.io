# 04_tables.jl
# Generates three standalone LaTeX table fragments from regression results.
# Outputs: output/table7_payer_pooled.tex
#          output/table12_payer_round1.tex
#          output/table13_payer_round2.tex

include(joinpath(@__DIR__, "00_setup.jl"))
using Printf

# ── Constants ─────────────────────────────────────────────────────────────────

const PANEL_MAP = [
    ("Pooled",  "table7_payer_pooled.tex",  "Table 7: Payer Domain --- Pooled"),
    ("Round 1", "table12_payer_round1.tex", "Table 12: Payer Domain --- Round 1"),
    ("Round 2", "table13_payer_round2.tex", "Table 13: Payer Domain --- Round 2"),
]

const OUTCOME_ORDER = [
    "Response", "Non-neg Availability", "Avail: Yes", "Avail: No",
    "Unclear Availability", "Avail: Waitlist", "Positive Sentiment", "No. of Responses"
]

# Column header labels (one per outcome, in order)
const COL_HEADERS = [
    "Response", "Non-neg Avail", "Avail: Yes", "Avail: No",
    "Unclear Avail", "Avail: Waitlist", "Positive Sentiment", "No. of Responses"
]

const CELL_MEAN_LABELS = ["Private Pay", "Medicaid", "No Payer"]

const CONTRAST_LABELS = ["Private - Medicaid", "Private - None", "Medicaid - None"]

# ── Helpers ───────────────────────────────────────────────────────────────────

"""
    fmt_num(x) -> String

Format a floating-point number to 3 decimal places, or return "" for NaN/missing.
"""
function fmt_num(x)
    ismissing(x) || isnan(x) ? "" : @sprintf("%.3f", x)
end

"""
    fmt_n(n::Integer) -> String

Format an integer sample size with comma thousands separator (e.g. 5609 -> "5,609").
"""
function fmt_n(n::Integer)
    s = string(n)
    # Insert commas every 3 digits from the right
    result = IOBuffer()
    len = length(s)
    for (i, c) in enumerate(s)
        print(result, c)
        remaining = len - i
        if remaining > 0 && remaining % 3 == 0
            print(result, ",")
        end
    end
    String(take!(result))
end

"""
    build_row(label::String, cells::Vector{String}) -> String

Build a single LaTeX table row: label followed by tab-separated cells, ending with `\\\\`.
"""
function build_row(label::String, cells::Vector{String})
    joined = join(cells, " & ")
    "$(label) & $(joined) \\\\"
end

"""
    build_row_indent(cells::Vector{String}, suffix::String="") -> String

Build a LaTeX row with no label (empty first column), used for SE/p/q rows.
`suffix` appends extra LaTeX after `\\\\` (e.g. `[6pt]` for spacing).
"""
function build_row_indent(cells::Vector{String}, suffix::String="")
    joined = join(cells, " & ")
    " & $(joined) \\\\$(suffix)"
end

# ── Core table builder ────────────────────────────────────────────────────────

"""
    build_table(panel_results::DataFrame, panel_sizes::DataFrame, caption::String) -> String

Construct the full LaTeX fragment for one panel's table.
"""
function build_table(panel_results::DataFrame, panel_sizes::DataFrame, caption::String)

    # Index results by (outcome, row_type, label) for fast lookup
    lookup = Dict{Tuple{String,String,String}, DataFrameRow}()
    for row in eachrow(panel_results)
        lookup[(row.outcome, row.row_type, row.label)] = row
    end

    # Index sample sizes by outcome
    n_lookup = Dict{String, Int}()
    for row in eachrow(panel_sizes)
        n_lookup[row.outcome] = row.n
    end

    lines = String[]

    # ── Table preamble ────────────────────────────────────────────────────────
    push!(lines, "\\begin{table}[htbp]")
    push!(lines, "\\centering")
    push!(lines, "\\begin{threeparttable}")
    push!(lines, "\\caption{$(caption)}")
    push!(lines, "\\footnotesize")
    push!(lines, "\\begin{tabular}{lcccccccc}")
    push!(lines, "\\toprule")

    # Column number row
    col_nums = join(["($(i))" for i in 1:8], " & ")
    push!(lines, " & $(col_nums) \\\\")

    # Column header row
    col_hdrs = join(COL_HEADERS, " & ")
    push!(lines, " & $(col_hdrs) \\\\")
    push!(lines, "\\midrule")

    # ── Cell means block ──────────────────────────────────────────────────────
    for lbl in CELL_MEAN_LABELS
        cells = String[]
        for outcome in OUTCOME_ORDER
            key = (outcome, "cell_mean", lbl)
            if haskey(lookup, key)
                push!(cells, fmt_num(lookup[key].estimate))
            else
                push!(cells, "")
            end
        end
        push!(lines, build_row(lbl, cells))
    end

    push!(lines, "\\midrule")

    # ── Contrasts block ───────────────────────────────────────────────────────
    for (ci, contrast_lbl) in enumerate(CONTRAST_LABELS)
        # Estimate row (label + values)
        est_cells = String[]
        se_cells  = String[]
        pv_cells  = String[]
        qv_cells  = String[]

        for outcome in OUTCOME_ORDER
            key = (outcome, "contrast", contrast_lbl)
            if haskey(lookup, key)
                r = lookup[key]
                push!(est_cells, fmt_num(r.estimate))
                push!(se_cells,  "($(fmt_num(r.se)))")
                push!(pv_cells,  "\\{$(fmt_num(r.pvalue))\\}")
                push!(qv_cells,  "[$(fmt_num(r.qvalue))]")
            else
                push!(est_cells, "")
                push!(se_cells,  "")
                push!(pv_cells,  "")
                push!(qv_cells,  "")
            end
        end

        push!(lines, build_row(contrast_lbl, est_cells))
        push!(lines, build_row_indent(se_cells))
        push!(lines, build_row_indent(pv_cells))

        # Add vertical spacing after q-value row except for the last contrast
        spacing = ci < length(CONTRAST_LABELS) ? "[6pt]" : ""
        push!(lines, build_row_indent(qv_cells, spacing))
    end

    push!(lines, "\\midrule")

    # ── Sample size row ───────────────────────────────────────────────────────
    n_cells = String[]
    for outcome in OUTCOME_ORDER
        if haskey(n_lookup, outcome)
            push!(n_cells, fmt_n(n_lookup[outcome]))
        else
            push!(n_cells, "")
        end
    end
    push!(lines, build_row("N", n_cells))

    # ── Table closing ─────────────────────────────────────────────────────────
    push!(lines, "\\bottomrule")
    push!(lines, "\\end{tabular}")
    push!(lines, "\\begin{tablenotes}[flushleft]")
    push!(lines, "\\small")
    push!(lines, "\\item \\textit{Notes:} Standard errors clustered at the SNF level in " *
          "parentheses. Two-sided p-values in curly braces. Sharpened FDR q-values " *
          "(Benjamini, Krieger, and Yekutieli, 2006) in square brackets. Q-values " *
          "adjusted jointly across all payer-domain panels and outcomes.")
    push!(lines, "\\end{tablenotes}")
    push!(lines, "\\end{threeparttable}")
    push!(lines, "\\end{table}")

    join(lines, "\n")
end

# ── Main ──────────────────────────────────────────────────────────────────────

results = CSV.read(joinpath(DATA_PROC, "regression_results_with_qvals.csv"), DataFrame)
sizes   = CSV.read(joinpath(DATA_PROC, "regression_sample_sizes.csv"), DataFrame)

mkpath(OUTPUT_DIR)

for (panel_name, filename, caption) in PANEL_MAP
    panel_results = filter(r -> r.panel == panel_name, results)
    panel_sizes   = filter(r -> r.panel == panel_name, sizes)

    tex = build_table(panel_results, panel_sizes, caption)

    out_path = joinpath(OUTPUT_DIR, filename)
    open(out_path, "w") do io
        println(io, tex)
    end

    println("Wrote: ", out_path)
end
