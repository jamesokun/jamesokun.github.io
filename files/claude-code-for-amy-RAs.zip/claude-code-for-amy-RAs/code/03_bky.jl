# 03_bky.jl
# Applies the Benjamini-Krieger-Yekutieli (2006) two-stage sharpened FDR
# procedure to all 72 contrast p-values from the regression results, then
# appends a qvalue column and saves the augmented table.
#
# Input:  data/processed/regression_results.csv       (144 rows)
# Output: data/processed/regression_results_with_qvals.csv  (144 rows + qvalue col)

include(joinpath(@__DIR__, "00_setup.jl"))

# ── BKY two-stage sharpened FDR ───────────────────────────────────────────────

"""
    bky_qvalues(pvalues) -> Vector{Float64}

Compute sharpened FDR q-values using the Benjamini, Krieger, and Yekutieli
(2006) two-stage procedure, following the grid-search implementation in
Anderson (2008).

For each candidate q on a grid from 1.0 down to 0.001, the procedure:
1. Computes q' = q / (1 + q) (the BKY conservative adjustment).
2. Runs a BH step-up at level q' to get initial rejections r1.
3. Re-estimates the number of true nulls as m0 = m - r1 and re-runs BH
   at level q' * (m / m0).
4. Assigns q to all tests rejected in stage 2.

The smallest q at which each test is rejected becomes its q-value.

# References
- Benjamini, Y., Krieger, A. M., & Yekutieli, D. (2006). Adaptive linear
  step-up procedures that control the false discovery rate. *Biometrika*, 93(3),
  491-507.
- Anderson, M. L. (2008). Multiple inference and gender differences in the
  effects of early intervention: A reevaluation of the Abecedarian, Perry
  Preschool, and Early Training Projects. *JASA*, 103(484), 1481-1495.
"""
function bky_qvalues(pvalues::Vector{Float64})
    m = length(pvalues)
    ord = sortperm(pvalues)
    p_sorted = pvalues[ord]
    r = collect(1:m)

    bky = ones(m)  # q-values for sorted p-values, initialised to 1

    for q in 1.0:-0.001:0.001
        q_prime = q / (1.0 + q)

        # Stage 1: BH step-up at level q'
        thr1 = q_prime .* r ./ m
        reject1 = p_sorted .<= thr1
        r1 = any(reject1) ? maximum(r[reject1]) : 0

        if r1 > 0 && r1 < m
            # Stage 2: adjust for estimated true nulls
            q2 = q_prime * (m / (m - r1))
            thr2 = q2 .* r ./ m
            reject2 = p_sorted .<= thr2
            r2 = any(reject2) ? maximum(r[reject2]) : 0
            if r2 > 0
                bky[1:r2] .= min.(bky[1:r2], q)
            end
        elseif r1 == m
            bky .= min.(bky, q)
        end
    end

    # Map back to original order
    out = Vector{Float64}(undef, m)
    for (i, idx) in enumerate(ord)
        out[idx] = bky[i]
    end
    return out
end

# ── Load regression results ───────────────────────────────────────────────────

results_path = joinpath(DATA_PROC, "regression_results.csv")
df = CSV.read(results_path, DataFrame)

println("Loaded regression_results.csv: ", nrow(df), " rows, ", ncol(df), " columns")

# ── Extract contrast rows and validate count ──────────────────────────────────

contrast_mask = df.row_type .== "contrast"
n_contrasts = sum(contrast_mask)

@assert n_contrasts == 72 "Expected exactly 72 contrast rows, found $n_contrasts"

println("Contrast rows: ", n_contrasts, " (3 contrasts x 8 outcomes x 3 panels)")

# ── Compute BKY q-values jointly across all 72 contrasts ─────────────────────

contrast_pvals = df.pvalue[contrast_mask]
@assert all(!isnan, contrast_pvals) "NaN p-values found among contrast rows"

qvals_contrasts = bky_qvalues(contrast_pvals)

println("BKY q-values computed. Range: [",
        round(minimum(qvals_contrasts), digits=4), ", ",
        round(maximum(qvals_contrasts), digits=4), "]")

# ── Append qvalue column (NaN for cell_mean rows) ────────────────────────────

df.qvalue = fill(NaN, nrow(df))
df.qvalue[contrast_mask] = qvals_contrasts

# ── Save augmented results ────────────────────────────────────────────────────

out_path = joinpath(DATA_PROC, "regression_results_with_qvals.csv")
CSV.write(out_path, df)

println("Saved: ", out_path)
println("  Total rows: ", nrow(df))
println("  Contrast rows with q-values: ", sum(.!isnan.(df.qvalue)))
