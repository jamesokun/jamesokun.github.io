# 05_writeup.jl
# Generates a compilable master LaTeX document that inputs the three payer-domain
# table fragments produced by 04_tables.jl.
# Output: output/payer_tables_writeup.tex

include(joinpath(@__DIR__, "00_setup.jl"))

tex = raw"""
\documentclass[12pt]{article}

\usepackage[margin=0.75in]{geometry}
\usepackage{booktabs}
\usepackage{threeparttable}
\usepackage{caption}
\usepackage{amsmath}
\usepackage{pdflscape}

\title{Payer Domain Results: Pooled and Round-Specific Estimates}
\author{}
\date{}

\begin{document}
\maketitle

\begin{landscape}

\section{Pooled Estimates (Pilot + Round 1 + Round 2)}
\input{table7_payer_pooled.tex}

\clearpage
\section{Round 1 Estimates}
\input{table12_payer_round1.tex}

\clearpage
\section{Round 2 Estimates}
\input{table13_payer_round2.tex}

\end{landscape}

\end{document}
"""

mkpath(OUTPUT_DIR)
open(joinpath(OUTPUT_DIR, "payer_tables_writeup.tex"), "w") do io
    print(io, tex)
end

println("Wrote: ", joinpath(OUTPUT_DIR, "payer_tables_writeup.tex"))
