# 02_regressions.jl
# Runs OLS regressions for 8 outcomes x 3 panels, extracts payer cell means
# and pairwise contrasts with SNF-clustered standard errors.
#
# Input:  data/processed/snf_round_panel.csv
# Output: data/processed/regression_results.csv
#         data/processed/regression_sample_sizes.csv

include(joinpath(@__DIR__, "00_setup.jl"))
using Distributions  # Term, ConstantTerm are re-exported by GLM via StatsModels

# ── 1. Load processed panel ───────────────────────────────────────────────────

df_full = CSV.read(joinpath(DATA_PROC, "snf_round_panel.csv"), DataFrame)

# has_reply is read back as Bool from CSV
println("Loaded panel: $(nrow(df_full)) rows")

# ── 2. Clustered VCV (sandwich estimator, HC1 small-sample correction) ────────

"""
    clustered_vcv(model, cluster_ids)

Compute a cluster-robust variance-covariance matrix for `model`, clustering
observations by `cluster_ids` (a vector of group identifiers).

Uses the HC1 small-sample adjustment:  G/(G-1) * (n-1)/(n-k).

# Arguments
- `model`: a fitted `GLM.LinearModel`
- `cluster_ids`: a vector of cluster identifiers, one per observation

# Returns
A `k × k` matrix (same dimensions as `vcov(model)`).
"""
function clustered_vcv(model, cluster_ids)
    X        = modelmatrix(model)
    e        = residuals(model)
    n        = length(e)
    k        = size(X, 2)
    clusters = unique(cluster_ids)
    G        = length(clusters)

    # Meat: sum of outer products of cluster-level score totals
    meat = zeros(k, k)
    for g in clusters
        idx    = findall(cluster_ids .== g)
        Xe_g   = X[idx, :]' * e[idx]
        meat .+= Xe_g * Xe_g'
    end

    # Bread: (X'X)^{-1}
    bread = inv(X' * X)

    # HC1 small-sample adjustment: G/(G-1) * (n-1)/(n-k)
    adj = (G / (G - 1)) * ((n - 1) / (n - k))

    return adj .* bread * meat * bread
end

# ── 3. Outcome and panel definitions ─────────────────────────────────────────

# (column_symbol, display_label, restrict_to_responders)
const OUTCOMES = [
    (:response,           "Response",             false),
    (:non_neg_avail,      "Non-neg Availability", false),
    (:avail_yes,          "Avail: Yes",           false),
    (:avail_no,           "Avail: No",            false),
    (:avail_unclear,      "Unclear Availability", false),
    (:avail_waitlist,     "Avail: Waitlist",      false),
    (:positive_sentiment, "Positive Sentiment",   false),
    (:num_responses,      "No. of Responses",     true),   # restrict to responders
]

# (display_label, round_filter)  — nothing means pooled (all rounds)
const PANELS = [
    ("Pooled",  nothing),
    ("Round 1", 1),
    ("Round 2", 2),
]

# ── 4. Regression loop ────────────────────────────────────────────────────────

results      = DataFrame(panel    = String[],
                         outcome  = String[],
                         row_type = String[],
                         label    = String[],
                         estimate = Float64[],
                         se       = Float64[],
                         pvalue   = Float64[])

sample_sizes = DataFrame(panel   = String[],
                         outcome = String[],
                         n       = Int[])

for (panel_label, round_filter) in PANELS
    for (yvar, outcome_label, restrict_responders) in OUTCOMES

        # ── 4a. Subset ────────────────────────────────────────────────────────

        df = copy(df_full)

        # Filter by round when not pooled
        if !isnothing(round_filter)
            filter!(r -> r.round == round_filter, df)
        end

        # For num_responses, restrict to rows that have a reply
        if restrict_responders
            filter!(r -> r.has_reply == true, df)
        end

        n_obs = nrow(df)
        push!(sample_sizes, (panel_label, outcome_label, n_obs))

        # ── 4b. Re-encode categoricals on the subset ──────────────────────────

        # Always re-encode so level sets reflect the actual subset
        df.payer         = categorical(string.(df.payer))
        df.race          = categorical(string.(df.race))
        df.day_of_week   = categorical(string.(df.day_of_week),
                                       levels = ["Mon", "Tue", "Wed", "Thu", "Fri"])

        # Binary vignette encoding: vignette 4 vs. vignettes 1–3 (matches R code)
        df.vignette_4      = Int.(string.(df.vignette_group) .== "4")
        df.other_vignette  = Int.(string.(df.vignette_group) .!= "4")

        # ── 4c. Build formula programmatically ───────────────────────────────

        # With ConstantTerm(0) (no intercept) the first categorical term gets
        # full k-level dummies; subsequent terms get k-1 (reference coding).
        # payer is listed first so we recover all 3 payer dummies directly.

        rhs_terms = Term[
            Term(:payer),
            Term(:race),
            Term(:vignette_4),
            Term(:day_of_week),
        ]

        if isnothing(round_filter)
            # Pooled: include a round indicator
            df.round_cat = categorical(string.(df.round))
            push!(rhs_terms, Term(:round_cat))
        end

        f = Term(yvar) ~ foldl(+, rhs_terms; init = ConstantTerm(0))

        # ── 4d. Fit OLS ───────────────────────────────────────────────────────

        m = lm(f, df)

        β      = coef(m)
        cnames = coefnames(m)
        V      = clustered_vcv(m, df.snf)

        # ── 4e. Locate payer cell-mean coefficients ───────────────────────────

        payer_labels = ["payer: Private Pay", "payer: Medicaid", "payer: No Payer"]
        payer_idx    = [findfirst(==(lbl), cnames) for lbl in payer_labels]

        @assert all(!isnothing, payer_idx) "Could not find payer coefficients in: $cnames"

        i_priv, i_mcd, i_none = payer_idx

        # ── 4f. Push cell means (no p-value) ─────────────────────────────────

        for (idx, lbl) in zip(payer_idx, ["Private Pay", "Medicaid", "No Payer"])
            push!(results, (
                panel_label, outcome_label, "cell_mean", lbl,
                β[idx], sqrt(V[idx, idx]), NaN
            ))
        end

        # ── 4g. Compute and push pairwise contrasts ───────────────────────────

        contrasts = [
            ("Private - Medicaid", i_priv, i_mcd),
            ("Private - None",     i_priv, i_none),
            ("Medicaid - None",    i_mcd,  i_none),
        ]

        for (clabel, i1, i2) in contrasts
            diff = β[i1] - β[i2]
            se   = sqrt(V[i1, i1] + V[i2, i2] - 2 * V[i1, i2])
            pval = 2 * (1 - cdf(Normal(), abs(diff / se)))
            push!(results, (
                panel_label, outcome_label, "contrast", clabel,
                diff, se, pval
            ))
        end

    end  # outcomes loop
end  # panels loop

# ── 5. Validate row count ─────────────────────────────────────────────────────

expected_rows = 3 * 8 * (3 + 3)   # 3 panels × 8 outcomes × 6 rows each = 144
@assert nrow(results) == expected_rows "Expected $expected_rows result rows, got $(nrow(results))"

println("Regression results: $(nrow(results)) rows (expected $expected_rows)")

# ── 6. Save outputs ───────────────────────────────────────────────────────────

mkpath(DATA_PROC)

results_path      = joinpath(DATA_PROC, "regression_results.csv")
sample_sizes_path = joinpath(DATA_PROC, "regression_sample_sizes.csv")

CSV.write(results_path, results)
CSV.write(sample_sizes_path, sample_sizes)

println("Saved regression results to:  ", results_path)
println("Saved sample sizes to:        ", sample_sizes_path)
