# 00_setup.jl
# Activates the project environment and loads common packages.
# Run this (or include it) at the top of every analysis script:
#
#   include("code/00_setup.jl")
#
# Or start Julia with:
#   julia --project=. code/00_setup.jl

using Pkg
Pkg.activate(joinpath(@__DIR__, ".."))   # project root contains Project.toml
Pkg.instantiate()                        # download any missing packages

# ── Data wrangling ────────────────────────────────────────────────────────────
using CSV
using DataFrames
using CategoricalArrays
using Statistics
using StatsBase

# ── Regression / statistical tests ───────────────────────────────────────────
using GLM
using HypothesisTests
using FixedEffectModels

# ── Visualization ─────────────────────────────────────────────────────────────
using CairoMakie        # publication-quality vector output
using StatsPlots        # statistical plot recipes (works with Plots backend too)

# ── Convenience constants ─────────────────────────────────────────────────────
const PROJECT_ROOT  = joinpath(@__DIR__, "..")
const DATA_RAW      = joinpath(PROJECT_ROOT, "data", "raw")
const DATA_PROC     = joinpath(PROJECT_ROOT, "data", "processed")
const OUTPUT_DIR    = joinpath(PROJECT_ROOT, "output")

println("Environment ready.  Julia ", VERSION)
println("  DATA_RAW  => ", DATA_RAW)
println("  DATA_PROC => ", DATA_PROC)
println("  OUTPUT    => ", OUTPUT_DIR)
