# 01_clean.jl
# Loads the raw SNF-round panel, recodes key columns, constructs outcome
# variables, and saves a clean CSV to data/processed/.
#
# Input:  data/raw/round_sentiment_merged_v4.csv   (5,609 rows)
# Output: data/processed/snf_round_panel.csv

include(joinpath(@__DIR__, "00_setup.jl"))

# ── 1. Load raw data ──────────────────────────────────────────────────────────

raw = CSV.read(joinpath(DATA_RAW, "round_sentiment_merged_v4.csv"), DataFrame)

# ── 2. Recode payment -> payer ────────────────────────────────────────────────

# missing => "No Payer", "Private" => "Private Pay", "Medicaid" unchanged
function recode_payment(val)
    ismissing(val)       && return "No Payer"
    val == "Private"     && return "Private Pay"
    return String(val)   # covers "Medicaid" and any unforeseen values unchanged
end

payer_vec = recode_payment.(raw.payment)

# ── 3. Extract vignette group (leading digit) ─────────────────────────────────

# e.g. "vignette_2b" -> "2", "vignette_3" -> "3"
function extract_vignette_group(v::AbstractString)
    m = match(r"vignette_(\d)", v)
    m === nothing && error("Unexpected vignette value: $v")
    return m.captures[1]
end

vignette_group_vec = extract_vignette_group.(raw.vignette)

# ── 4. Construct outcome variables ────────────────────────────────────────────

# 4a. response: Bool -> Int
response = Int.(raw.has_reply)

# 4b. availability-based outcomes (missing treated as 0)
avail = raw.availability_status   # Union{Missing, String}

non_neg_avail  = [(!ismissing(a) && a in ("Yes", "Unclear")) ? 1 : 0 for a in avail]
avail_yes      = [(!ismissing(a) && a == "Yes")      ? 1 : 0 for a in avail]
avail_no       = [(!ismissing(a) && a == "No")       ? 1 : 0 for a in avail]
avail_unclear  = [(!ismissing(a) && a == "Unclear")  ? 1 : 0 for a in avail]
avail_waitlist = [(!ismissing(a) && a == "Waitlist") ? 1 : 0 for a in avail]

# 4c. positive_sentiment (missing treated as 0)
positive_sentiment = [(!ismissing(s) && s == "Positive") ? 1 : 0
                      for s in raw.sentiment_label_max]

# 4d. num_responses: coalesce missing to 0
num_responses = coalesce.(raw.num_response, 0)

# ── 5. Assemble final DataFrame ───────────────────────────────────────────────

panel = DataFrame(
    snf             = raw.snf,
    round           = raw.round,
    payer           = CategoricalArray(payer_vec),
    race            = CategoricalArray(String.(raw.race)),
    vignette_group  = CategoricalArray(vignette_group_vec),
    day_of_week     = CategoricalArray(String.(raw.day_of_week)),
    # outcomes
    response        = response,
    non_neg_avail   = non_neg_avail,
    avail_yes       = avail_yes,
    avail_no        = avail_no,
    avail_unclear   = avail_unclear,
    avail_waitlist  = avail_waitlist,
    positive_sentiment = positive_sentiment,
    num_responses   = num_responses,
    # keep raw flag for downstream assertion
    has_reply       = raw.has_reply,
)

# ── 6. Assertions ─────────────────────────────────────────────────────────────

@assert nrow(panel) == 5609  "Expected 5609 rows, got $(nrow(panel))"
@assert count(panel.has_reply) == 1983  "Expected 1983 replies, got $(count(panel.has_reply))"

println("Assertions passed: $(nrow(panel)) rows, $(count(panel.has_reply)) replies.")

# ── 7. Save processed panel ───────────────────────────────────────────────────

mkpath(DATA_PROC)   # create directory if it does not yet exist
out_path = joinpath(DATA_PROC, "snf_round_panel.csv")
CSV.write(out_path, panel)

println("Saved clean panel to: ", out_path)
