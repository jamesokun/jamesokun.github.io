# Payer Domain Replication Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers-extended-cc:subagent-driven-development (if subagents available) or superpowers-extended-cc:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replicate Tables 7, 12, and 13 from a correspondence study — pooled and round-specific payer-domain estimates with clustered SEs, p-values, and BKY sharpened q-values, output as publication-quality LaTeX.

**Architecture:** Five sequential Julia scripts (01–05) forming a linear pipeline. Each reads from `data/processed/` or `data/raw/` and writes to `data/processed/` or `output/`. No shared library code — each script is self-contained via `include("code/00_setup.jl")`.

**Tech Stack:** Julia 1.9+, CSV.jl, DataFrames.jl, CategoricalArrays.jl, FixedEffectModels.jl, GLM.jl, Distributions.jl (for Normal CDF), HypothesisTests.jl

**Spec:** `docs/superpowers/specs/2026-03-16-payer-replication-design.md`

---

## Chunk 1: Data Cleaning

### Task 1: Data Cleaning (`code/01_clean.jl`)

**Files:**
- Create: `code/01_clean.jl`
- Read: `data/raw/round_sentiment_merged_v4.csv`
- Write: `data/processed/snf_round_panel.csv`

- [ ] **Step 1: Create `01_clean.jl` with setup and data load**

```julia
include("code/00_setup.jl")

# ── Load raw data ────────────────────────────────────────────────────────────
raw = CSV.read(joinpath(DATA_RAW, "round_sentiment_merged_v4.csv"), DataFrame)
@assert nrow(raw) == 5609 "Expected 5,609 rows, got $(nrow(raw))"
```

- [ ] **Step 2: Add payer recoding**

Recode `payment` column: `missing` -> `"No Payer"`, `"Private"` -> `"Private Pay"`, `"Medicaid"` unchanged.

```julia
# ── Recode payer ─────────────────────────────────────────────────────────────
raw.payer = map(raw.payment) do p
    ismissing(p) ? "No Payer" : p == "Private" ? "Private Pay" : String(p)
end
```

- [ ] **Step 3: Add vignette grouping**

Extract leading digit from vignette column (e.g., `vignette_2b` -> `"2"`, `vignette_3` -> `"3"`).

```julia
# ── Vignette groups ──────────────────────────────────────────────────────────
raw.vignette_group = map(raw.vignette) do v
    m = match(r"vignette_(\d)", v)
    String(m.captures[1])
end
```

- [ ] **Step 4: Construct outcome variables**

All binary outcomes are 0/1 integers. Missing availability/sentiment maps to 0 (non-responders counted as 0).

```julia
# ── Outcome variables ────────────────────────────────────────────────────────
raw.response         = Int.(raw.has_reply)
raw.non_neg_avail    = Int.(coalesce.(raw.availability_status .∈ Ref(("Yes","Unclear","Waitlist")), false))
raw.avail_yes        = Int.(coalesce.(raw.availability_status .== "Yes", false))
raw.avail_no         = Int.(coalesce.(raw.availability_status .== "No", false))
raw.avail_unclear    = Int.(coalesce.(raw.availability_status .== "Unclear", false))
raw.avail_waitlist   = Int.(coalesce.(raw.availability_status .== "Waitlist", false))
raw.positive_sentiment = Int.(coalesce.(raw.sentiment_label_max .== "Positive", false))
raw.num_responses    = coalesce.(raw.num_response, 0)
```

- [ ] **Step 5: Select and save processed panel**

Keep only the columns needed for regression. Encode categoricals.

```julia
# ── Select columns & encode categoricals ─────────────────────────────────────
panel = select(raw,
    :snf,
    :round,
    :payer   => (x -> categorical(x)) => :payer,
    :race    => (x -> categorical(x)) => :race,
    :vignette_group => (x -> categorical(x)) => :vignette_group,
    :day_of_week    => (x -> categorical(x)) => :day_of_week,
    :response,
    :non_neg_avail,
    :avail_yes,
    :avail_no,
    :avail_unclear,
    :avail_waitlist,
    :positive_sentiment,
    :num_responses,
    :has_reply,
)

@assert nrow(panel) == 5609
@assert count(panel.has_reply) == 1983

CSV.write(joinpath(DATA_PROC, "snf_round_panel.csv"), panel)
```

- [ ] **Step 6: Run the script end-to-end**

Run: `julia --project=. code/01_clean.jl`
Expected: Script completes without assertion errors, produces `data/processed/snf_round_panel.csv` with 5,609 rows.

- [ ] **Step 7: Commit**

```bash
git add code/01_clean.jl
git commit -m "feat: add data cleaning script (01_clean.jl)"
```

---

## Chunk 2: Regressions

### Task 2: Regressions (`code/02_regressions.jl`)

**Files:**
- Create: `code/02_regressions.jl`
- Read: `data/processed/snf_round_panel.csv`
- Write: `data/processed/regression_results.csv`

**Note on FixedEffectModels.jl and no-intercept models:** `FixedEffectModels.reg()` does not support suppressing the intercept via `0 +` syntax. Instead, use `GLM.lm()` for the no-intercept specification and compute clustered SEs manually via the sandwich estimator (HC1 with cluster grouping). Alternatively, use `FixedEffectModels.reg()` with the standard intercept + 2 payer dummies and recover cell means via linear combinations. The GLM approach is more direct for this spec.

**Chosen approach:** Use `GLM.lm()` with the `@formula(Y ~ 0 + ...)` syntax (which GLM supports), then compute the clustered VCV manually using the sandwich estimator grouped by SNF.

- [ ] **Step 1: Create `02_regressions.jl` with setup, data load, and helper functions**

```julia
include("code/00_setup.jl")
using Distributions  # must be added to Project.toml

# ── Load panel ───────────────────────────────────────────────────────────────
panel = CSV.read(joinpath(DATA_PROC, "snf_round_panel.csv"), DataFrame)

# ── Clustered VCV (HC1) ─────────────────────────────────────────────────────
function clustered_vcv(model, cluster_ids)
    X = modelmatrix(model)
    e = residuals(model)
    n = length(e)
    k = size(X, 2)
    clusters = unique(cluster_ids)
    G = length(clusters)

    # Meat: sum of outer products of cluster-level score totals
    meat = zeros(k, k)
    for g in clusters
        idx = findall(cluster_ids .== g)
        Xe_g = X[idx, :]' * e[idx]    # k×1 vector
        meat .+= Xe_g * Xe_g'
    end

    # Bread: (X'X)^{-1}
    bread = inv(X' * X)

    # HC1 small-sample adjustment: G/(G-1) * (n-1)/(n-k)
    adj = (G / (G - 1)) * ((n - 1) / (n - k))

    return adj .* bread * meat * bread
end
```

- [ ] **Step 2: Define outcome list and panel definitions**

```julia
# ── Outcomes and panels ──────────────────────────────────────────────────────
OUTCOMES = [
    (:response,           "Response",           false),
    (:non_neg_avail,      "Non-neg Availability", false),
    (:avail_yes,          "Avail: Yes",         false),
    (:avail_no,           "Avail: No",          false),
    (:avail_unclear,      "Unclear Availability", false),
    (:avail_waitlist,     "Avail: Waitlist",    false),
    (:positive_sentiment, "Positive Sentiment", false),
    (:num_responses,      "No. of Responses",   true),   # true = restrict to responders
]

PANELS = [
    ("Pooled",  nothing),     # nothing = no round filter
    ("Round 1", 1),
    ("Round 2", 2),
]
```

- [ ] **Step 3: Build the regression loop**

```julia
# ── Run regressions ──────────────────────────────────────────────────────────
results = DataFrame(
    panel=String[], outcome=String[], row_type=String[],
    label=String[], estimate=Float64[], se=Float64[], pvalue=Float64[]
)

for (panel_name, round_filter) in PANELS
    for (yvar, ylabel, restrict_responders) in OUTCOMES
        # Subset data
        df = if round_filter === nothing
            copy(panel)
        else
            filter(r -> r.round == round_filter, panel)
        end
        if restrict_responders
            filter!(r -> r.has_reply, df)
        end
        n = nrow(df)

        # Build formula — pooled includes round dummies
        if round_filter === nothing
            f = Term(yvar) ~ ConstantTerm(0) +
                Term(:payer) + Term(:race) + Term(:vignette_group) +
                Term(:day_of_week) + Term(:round)
        else
            f = Term(yvar) ~ ConstantTerm(0) +
                Term(:payer) + Term(:race) + Term(:vignette_group) +
                Term(:day_of_week)
        end

        # Encode categoricals in subset
        for col in [:payer, :race, :vignette_group, :day_of_week]
            df[!, col] = categorical(string.(df[!, col]))
        end
        if round_filter === nothing
            df[!, :round] = categorical(df.round)
        end

        # Fit
        m = lm(f, df)
        β = coef(m)
        cnames = coefnames(m)
        V = clustered_vcv(m, df.snf)

        # Extract payer cell means
        payer_labels = ["Private Pay", "Medicaid", "No Payer"]
        payer_coef_names = ["payer: Private Pay", "payer: Medicaid", "payer: No Payer"]
        payer_idx = [findfirst(cnames .== cn) for cn in payer_coef_names]
        @assert all(!isnothing, payer_idx) "Could not find payer coefficients in: $cnames"

        for (i, lbl) in enumerate(payer_labels)
            push!(results, (panel_name, ylabel, "cell_mean", lbl,
                            β[payer_idx[i]], sqrt(V[payer_idx[i], payer_idx[i]]), NaN))
        end

        # Contrasts
        contrasts = [
            ("Private - Medicaid", payer_idx[1], payer_idx[2]),
            ("Private - None",     payer_idx[1], payer_idx[3]),
            ("Medicaid - None",    payer_idx[2], payer_idx[3]),
        ]
        for (clbl, i1, i2) in contrasts
            diff = β[i1] - β[i2]
            se = sqrt(V[i1, i1] + V[i2, i2] - 2 * V[i1, i2])
            z = diff / se
            pval = 2 * (1 - cdf(Normal(), abs(z)))
            push!(results, (panel_name, ylabel, "contrast", clbl, diff, se, pval))
        end
    end
end

CSV.write(joinpath(DATA_PROC, "regression_results.csv"), results)
```

- [ ] **Step 4: Run the script end-to-end**

Run: `julia --project=. code/02_regressions.jl`
Expected: Completes without error. Produces `data/processed/regression_results.csv`. Quick sanity checks:
- 3 panels x 8 outcomes x (3 cell means + 3 contrasts) = 144 rows total
- Cell means for binary outcomes should be between 0 and 1
- p-values between 0 and 1

- [ ] **Step 5: Commit**

```bash
git add code/02_regressions.jl
git commit -m "feat: add regression script (02_regressions.jl)"
```

---

## Chunk 3: BKY Sharpened FDR

### Task 3: BKY q-values (`code/03_bky.jl`)

**Files:**
- Create: `code/03_bky.jl`
- Read: `data/processed/regression_results.csv`
- Write: `data/processed/regression_results_with_qvals.csv`

- [ ] **Step 1: Create `03_bky.jl` with the BKY function**

Port of Anderson (2008) two-stage sharpened FDR.

```julia
include("code/00_setup.jl")

# ── BKY (2006) sharpened q-values ────────────────────────────────────────────
function bky_qvalues(pvalues::Vector{Float64}; q::Float64=0.05)
    m = length(pvalues)
    sorted_idx = sortperm(pvalues)
    sorted_p = pvalues[sorted_idx]

    # Stage 1: BH step-up at level q
    bh_critical = [q * i / m for i in 1:m]
    r0_idx = findlast(sorted_p .<= bh_critical)
    r0 = r0_idx === nothing ? 0 : r0_idx

    # Stage 2: estimate number of true nulls m0, compute sharpened threshold
    m0 = m - r0  # estimated true nulls
    if m0 == 0; m0 = 1; end  # guard against all rejections

    # Compute sharpened q-values using m0 (not m) in denominator
    # This is the BKY "sharpening": use estimated m0 instead of total m
    qvals = zeros(m)
    qvals[sorted_idx[m]] = min(sorted_p[m] * m0 / m, 1.0)
    for i in (m-1):-1:1
        raw_q = sorted_p[i] * m0 / i
        qvals[sorted_idx[i]] = min(raw_q, qvals[sorted_idx[i+1]], 1.0)
    end

    return qvals
end
```

- [ ] **Step 2: Load results, apply BKY to contrast p-values, save**

```julia
# ── Apply to all contrast p-values ───────────────────────────────────────────
results = CSV.read(joinpath(DATA_PROC, "regression_results.csv"), DataFrame)

# Extract contrast rows (cell means have NaN p-values)
contrast_mask = results.row_type .== "contrast"
pvals = results.pvalue[contrast_mask]

@assert length(pvals) == 72 "Expected 72 contrast p-values, got $(length(pvals))"

qvals = bky_qvalues(pvals)

# Attach q-values (NaN for cell means)
results.qvalue = fill(NaN, nrow(results))
results.qvalue[contrast_mask] .= qvals

CSV.write(joinpath(DATA_PROC, "regression_results_with_qvals.csv"), results)
```

- [ ] **Step 3: Run the script**

Run: `julia --project=. code/03_bky.jl`
Expected: Produces `data/processed/regression_results_with_qvals.csv` with 144 rows and a `qvalue` column. All q-values between 0 and 1. q-values >= corresponding p-values.

- [ ] **Step 4: Commit**

```bash
git add code/03_bky.jl
git commit -m "feat: add BKY sharpened FDR script (03_bky.jl)"
```

---

## Chunk 4: LaTeX Tables and Writeup

### Task 4: LaTeX Tables (`code/04_tables.jl`)

**Files:**
- Create: `code/04_tables.jl`
- Read: `data/processed/regression_results_with_qvals.csv`
- Write: `output/table7_payer_pooled.tex`, `output/table12_payer_round1.tex`, `output/table13_payer_round2.tex`

**Note:** Use the `econ-regression-table` skill when implementing this task. The skill generates publication-quality LaTeX regression tables for economics papers.

- [ ] **Step 1: Create `04_tables.jl` with table formatting function**

The table layout per the spec:
- 8 columns (one per outcome)
- Row block 1: cell means for Private Pay, Medicaid, No Payer
- Row block 2: for each of 3 contrasts — estimate, (SE), {p-value}, [q-value]
- Footer: N (5,609 for cols 1-7, 1,983 for col 8 in pooled; panel-specific Ns for round tables)

```julia
include("code/00_setup.jl")
using Printf

results = CSV.read(joinpath(DATA_PROC, "regression_results_with_qvals.csv"), DataFrame)
panel_data = CSV.read(joinpath(DATA_PROC, "snf_round_panel.csv"), DataFrame)

# ── Formatting helpers ───────────────────────────────────────────────────────
fmt3(x) = isnan(x) ? "" : @sprintf("%.3f", x)
fmt_se(x) = isnan(x) ? "" : @sprintf("(%.3f)", x)
fmt_pval(x) = isnan(x) ? "" : @sprintf("\\{%.3f\\}", x)
fmt_qval(x) = isnan(x) ? "" : @sprintf("[%.3f]", x)

OUTCOME_ORDER = [
    "Response", "Non-neg Availability", "Avail: Yes", "Avail: No",
    "Unclear Availability", "Avail: Waitlist", "Positive Sentiment", "No. of Responses"
]

PANEL_MAP = Dict(
    "Pooled"  => ("table7_payer_pooled.tex",  "Table 7: Payer Domain — Pooled"),
    "Round 1" => ("table12_payer_round1.tex", "Table 12: Payer Domain — Round 1"),
    "Round 2" => ("table13_payer_round2.tex", "Table 13: Payer Domain — Round 2"),
)
```

- [ ] **Step 2: Add table generation loop**

Use the `econ-regression-table` skill to guide the LaTeX structure. The function should generate a `booktabs`-style tabular environment with `threeparttable` for notes.

```julia
# ── Generate tables ──────────────────────────────────────────────────────────
for panel_name in ["Pooled", "Round 1", "Round 2"]
    filename, caption = PANEL_MAP[panel_name]
    pr = filter(r -> r.panel == panel_name, results)

    # Build LaTeX
    ncols = length(OUTCOME_ORDER)
    col_spec = "l" * "c"^ncols

    lines = String[]
    push!(lines, "\\begin{table}[htbp]")
    push!(lines, "\\centering")
    push!(lines, "\\begin{threeparttable}")
    push!(lines, "\\caption{$caption}")
    push!(lines, "\\small")
    push!(lines, "\\begin{tabular}{$col_spec}")
    push!(lines, "\\toprule")

    # Header row
    header = " & " * join(["($i)" for i in 1:ncols], " & ") * " \\\\"
    push!(lines, header)
    outcome_header = " & " * join([replace(o, "&" => "\\&") for o in OUTCOME_ORDER], " & ") * " \\\\"
    push!(lines, outcome_header)
    push!(lines, "\\midrule")

    # Cell means
    for lbl in ["Private Pay", "Medicaid", "No Payer"]
        row_data = [filter(r -> r.outcome == o && r.row_type == "cell_mean" && r.label == lbl, pr)
                    for o in OUTCOME_ORDER]
        vals = [nrow(rd) > 0 ? fmt3(rd.estimate[1]) : "" for rd in row_data]
        push!(lines, "$lbl & " * join(vals, " & ") * " \\\\")
    end

    push!(lines, "\\midrule")

    # Contrasts
    for clbl in ["Private - Medicaid", "Private - None", "Medicaid - None"]
        row_data = [filter(r -> r.outcome == o && r.row_type == "contrast" && r.label == clbl, pr)
                    for o in OUTCOME_ORDER]

        # Estimate row
        vals = [nrow(rd) > 0 ? fmt3(rd.estimate[1]) : "" for rd in row_data]
        push!(lines, "$clbl & " * join(vals, " & ") * " \\\\")

        # SE row
        ses = [nrow(rd) > 0 ? fmt_se(rd.se[1]) : "" for rd in row_data]
        push!(lines, " & " * join(ses, " & ") * " \\\\")

        # p-value row
        ps = [nrow(rd) > 0 ? fmt_pval(rd.pvalue[1]) : "" for rd in row_data]
        push!(lines, " & " * join(ps, " & ") * " \\\\")

        # q-value row
        qs = [nrow(rd) > 0 ? fmt_qval(rd.qvalue[1]) : "" for rd in row_data]
        push!(lines, " & " * join(qs, " & ") * " \\\\[6pt]")
    end

    push!(lines, "\\midrule")

    # Sample size row — compute N per outcome for this panel
    pdf = if panel_name == "Pooled"
        panel_data
    elseif panel_name == "Round 1"
        filter(r -> r.round == 1, panel_data)
    else
        filter(r -> r.round == 2, panel_data)
    end
    n_binary = string(nrow(pdf))
    n_count = string(count(pdf.has_reply))
    ns = [i < ncols ? n_binary : n_count for i in 1:ncols]
    push!(lines, "N & " * join(ns, " & ") * " \\\\")

    push!(lines, "\\bottomrule")
    push!(lines, "\\end{tabular}")
    push!(lines, "\\begin{tablenotes}[flushleft]")
    push!(lines, "\\small")
    push!(lines, "\\item \\textit{Notes:} Standard errors clustered at the SNF level in parentheses. Two-sided p-values in curly braces. Sharpened FDR q-values (Benjamini, Krieger, and Yekutieli, 2006) in square brackets. Q-values adjusted jointly across all payer-domain panels and outcomes.")
    push!(lines, "\\end{tablenotes}")
    push!(lines, "\\end{threeparttable}")
    push!(lines, "\\end{table}")

    # Write
    open(joinpath(OUTPUT_DIR, filename), "w") do io
        println(io, join(lines, "\n"))
    end
end
```

- [ ] **Step 3: Run the script**

Run: `julia --project=. code/04_tables.jl`
Expected: Produces three `.tex` files in `output/`. Each is a valid LaTeX table fragment.

- [ ] **Step 4: Commit**

```bash
git add code/04_tables.jl
git commit -m "feat: add LaTeX table generation (04_tables.jl)"
```

### Task 5: LaTeX Writeup (`code/05_writeup.jl`)

**Files:**
- Create: `code/05_writeup.jl`
- Write: `output/payer_tables_writeup.tex`

- [ ] **Step 1: Create `05_writeup.jl`**

```julia
include("code/00_setup.jl")

tex = raw"""
\documentclass[12pt]{article}

\usepackage[margin=1in]{geometry}
\usepackage{booktabs}
\usepackage{threeparttable}
\usepackage{caption}
\usepackage{amsmath}

\title{Payer Domain Results: Pooled and Round-Specific Estimates}
\author{}
\date{}

\begin{document}
\maketitle

\section{Pooled Estimates (Pilot + Round 1 + Round 2)}
\input{table7_payer_pooled.tex}

\clearpage
\section{Round 1 Estimates}
\input{table12_payer_round1.tex}

\clearpage
\section{Round 2 Estimates}
\input{table13_payer_round2.tex}

\end{document}
"""

open(joinpath(OUTPUT_DIR, "payer_tables_writeup.tex"), "w") do io
    print(io, tex)
end
```

- [ ] **Step 2: Run the script**

Run: `julia --project=. code/05_writeup.jl`
Expected: Produces `output/payer_tables_writeup.tex`.

- [ ] **Step 3: Verify LaTeX compiles (optional)**

Run: `cd output && pdflatex payer_tables_writeup.tex`
Expected: Compiles to PDF without errors (requires LaTeX installation).

- [ ] **Step 4: Commit**

```bash
git add code/05_writeup.jl
git commit -m "feat: add LaTeX writeup generator (05_writeup.jl)"
```
