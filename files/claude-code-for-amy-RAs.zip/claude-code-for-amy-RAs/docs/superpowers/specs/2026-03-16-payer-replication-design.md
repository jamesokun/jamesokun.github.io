
**Date:** 2026-03-16
**Status:** Approved

## Overview

Blind replication of the payer-domain results from a correspondence study of skilled nursing facilities (SNFs). Produces three publication-quality LaTeX tables (pooled, Round 1, Round 2) estimating differential responsiveness and availability by payer type (Private Pay, Medicaid, No Payer).

## Approach

Linear pipeline of numbered Julia scripts following project conventions. Each script includes `00_setup.jl` and uses the shared path constants.

## Pipeline

### `01_clean.jl` — Data Cleaning

- **Input:** `data/raw/round_sentiment_merged_v4.csv` (5,609 rows, already at SNF-round level)
- **Output:** `data/processed/snf_round_panel.csv`

The raw data is already collapsed to one row per SNF-round. No aggregation needed. Steps:

1. Load CSV (confirm 5,609 rows)
2. Recode `payment` column: `missing` -> `"No Payer"`, `"Private"` -> `"Private Pay"`, `"Medicaid"` stays as-is
3. Map vignette column to 4 groups: extract leading digit from values like `vignette_1a`, `vignette_2b`, etc. (Pilot-era values `vignette_1`, `vignette_2`, ... map directly to groups 1-4)
4. Construct 8 outcome variables from existing columns:

| Outcome | Column | Construction |
|---------|--------|-------------|
| (1) Response | `response` | `has_reply == true` -> 1, else 0 |
| (2) Non-neg Availability | `non_neg_avail` | `availability_status in ("Yes", "Unclear", "Waitlist")` -> 1, else 0 (missing/non-response = 0) |
| (3) Avail: Yes | `avail_yes` | `availability_status == "Yes"` -> 1, else 0 |
| (4) Avail: No | `avail_no` | `availability_status == "No"` -> 1, else 0 |
| (5) Unclear Availability | `avail_unclear` | `availability_status == "Unclear"` -> 1, else 0 |
| (6) Avail: Waitlist | `avail_waitlist` | `availability_status == "Waitlist"` -> 1, else 0 |
| (7) Positive Sentiment | `positive_sentiment` | `sentiment_label_max == "Positive"` -> 1, else 0 (missing = 0) |
| (8) No. of Responses | `num_responses` | `num_response` (integer count); sample restricted to `has_reply == true` for this outcome only |

5. Encode treatment and control variables as categorical:
   - `payer`: 3 levels (Private Pay, Medicaid, No Payer)
   - `race`: from `race` column (White, Black)
   - `vignette_group`: 4 levels (1, 2, 3, 4)
   - `day_of_week`: from `day_of_week` column
   - `round`: integer 0 (Pilot), 1, 2
6. Confirm: N=5,609 total; N=1,983 where `has_reply == true`
7. Save processed panel

### `02_regressions.jl` — OLS Regressions

- **Input:** `data/processed/snf_round_panel.csv`
- **Output:** `data/processed/regression_results.csv`

**Package:** Use `FixedEffectModels.reg()` with `Vcov.cluster(:snf)` for built-in clustered SEs.

**Panels:**
- Pooled: all rows (N=5,609 for binary, N=1,983 for count)
- Round 1: `round == 1` only
- Round 2: `round == 2` only
- (Pilot observations, `round == 0`, appear only in the Pooled panel)

**Specification (no intercept, full payer dummies):**
```
Y ~ 0 + payer_private + payer_medicaid + payer_nopayer + race_black + vignette_2 + vignette_3 + vignette_4 + dow_controls + round_1 + round_2
```
- Round dummies (round_1, round_2) included in Pooled panel only; Pilot (round=0) is reference
- Round dummies omitted in single-round panels

For each of 8 outcomes x 3 panels:
1. Estimate OLS with SNF-clustered SEs
2. Extract three cell means (coefficients on payer dummies)
3. Compute three contrasts from the clustered VCV matrix:
   - Private-Medicaid, Private-None, Medicaid-None
   - `se(b1 - b2) = sqrt(var(b1) + var(b2) - 2*cov(b1, b2))`
   - Two-sided Wald p-value: `2 * (1 - cdf(Normal(), abs(contrast / se)))`
4. Column (8) restricts sample to `has_reply == true`

Output: DataFrame with columns `[panel, outcome, contrast, estimate, se, pvalue]` plus a row type indicator for cell means vs contrasts.

### `03_bky.jl` — BKY Sharpened FDR

- **Input:** `data/processed/regression_results.csv`
- **Output:** `data/processed/regression_results_with_qvals.csv`

Port of Anderson (2008) `sharpened_qvalues.do`. Pseudocode:

```
function bky_qvalues(pvalues; q=0.05)
    m = length(pvalues)
    sorted_indices = sortperm(pvalues)
    sorted_p = pvalues[sorted_indices]

    # Stage 1: Standard BH step-up at level q
    bh_thresholds = [q * i / m for i in 1:m]
    r0 = findlast(sorted_p .<= bh_thresholds)
    if r0 === nothing; r0 = 0; end

    # Stage 2: Estimate number of true nulls, compute sharpened q-values
    m0 = m - r0  # estimated true nulls
    if m0 == 0; m0 = 1; end

    # Compute q-values using m0 (not m) — this is the BKY "sharpening"
    qvalues = similar(pvalues)
    for i in m:-1:1
        qval = sorted_p[i] * m0 / i
        if i < m
            qval = min(qval, qvalues[sorted_indices[i+1]])  # enforce monotonicity
        end
        qvalues[sorted_indices[i]] = min(qval, 1.0)
    end
    return qvalues
end
```

Applied jointly to all 72 p-values (3 contrasts x 8 outcomes x 3 panels).

### `04_tables.jl` — LaTeX Table Generation

- **Input:** `data/processed/regression_results_with_qvals.csv`
- **Output:** `output/table7_payer_pooled.tex`, `output/table12_payer_round1.tex`, `output/table13_payer_round2.tex`

Each table contains:
- Row block 1: Cell means (Private Pay, Medicaid, No Payer)
- Row block 2: Three contrasts (Private-Medicaid, Private-None, Medicaid-None), each with:
  - Point estimate
  - (SE) in parentheses
  - {p-value} in curly braces
  - [q-value] in square brackets
- Footer: Sample size N

Uses `econ-regression-table` skill for formatting. Tables are standalone `.tex` fragments.

### `05_writeup.jl` — Master LaTeX Document

- **Output:** `output/payer_tables_writeup.tex`

Compilable LaTeX document containing:
- Document class and packages (booktabs, threeparttable, etc.)
- Section headers for each table
- `\input{table7_payer_pooled.tex}`, `\input{table12_payer_round1.tex}`, `\input{table13_payer_round2.tex}`
- Table notes explaining notation: () = SNF-clustered SE, {} = two-sided p-value, [] = BKY sharpened q-value

## Key Design Decisions

- **Blind replication:** No access to original results. All code written from the econometrics spec only.
- **Linear probability model throughout:** OLS for all outcomes including the count (column 8). No logit/probit/Poisson.
- **Intention-to-treat:** Observations coded by assigned treatment, not actual treatment received.
- **Joint FDR adjustment:** q-values computed jointly across all 3 panels (72 tests total), not per-panel.
- **BKY implementation:** Ported from Anderson (2008) Stata code.
- **Minimal diagnostics:** Fail loudly on errors, but no verbose printouts.
- **Data is pre-collapsed:** Raw file is already at SNF-round level (5,609 rows). No aggregation step needed.
- **No Payer = missing:** The `payment` column uses `missing` for the "No Payer" treatment arm; must be explicitly recoded.
- **Vignette grouping:** 20 raw vignette levels collapsed to 4 groups by leading digit.
- **Pilot in pooled only:** Round 0 (Pilot) observations included in pooled panel but not in Round 1 or Round 2 panels.

## Task IDs

- #4: Implement data cleaning (01_clean.jl)
- #5: Implement regressions (02_regressions.jl)
- #6: Implement BKY sharpened FDR (03_bky.jl)
- #7: Implement LaTeX tables (04_tables.jl)
- #8: Implement LaTeX writeup (05_writeup.jl)
