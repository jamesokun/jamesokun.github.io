# Econometrics Specification: Replicating Table 7 (Payer, Pooled)

## Overview

Table 7 reports pooled (Pilot + Round 1 + Round 2) estimates from the **payer domain** of a correspondence study of skilled nursing facilities (SNFs). The goal is to estimate differences in facility responsiveness and availability by payer type (Private Pay, Medicaid, No Payer).

---

## Unit of Analysis

**SNF–round.** Each observation is one facility in one experimental round. A facility can appear up to three times (once per round: Pilot, Round 1, Round 2). The pooled dataset has **5,609 observations** (for all outcomes except No. of Responses, which conditions on having at least one response: **1,983 observations**).

---

## Sample Construction

1. **Starting universe:** 4,223 SNFs were randomized across the pilot and two main rounds.
2. **Analysis sample:** Restrict to the **2,949 facilities that were successfully treated** (i.e., messages were actually sent).
3. **Collapse to SNF–round level:** Start from message-level data (emails and voicemails), match and code each message, then collapse to one record per facility per experimental round. Each SNF appears at most once per round.
4. **Exclude "Round 3" records:** When an SNF received two treatments in the same experimental round, the incorrect treatment was recoded as "Round 3." These observations are **excluded**.
5. **Intention-to-treat:** All SNFs are analyzed according to their **assigned** treatment, regardless of implementation discrepancies. The 10 cases flagged as `correct_treatment = 0` remain coded according to the original assignment.

---

## Outcome Variables

Table 7 reports eight outcomes (one per column):

| Column | Outcome | Definition |
|--------|---------|------------|
| (1) | Response | Any response (email or voicemail) received from the SNF in that round |
| (2) | Non-negative Availability | Availability coded as "Yes" or "Unclear" (excludes "Waitlist") |
| (3) | Avail: Yes | Availability explicitly coded as "yes" |
| (4) | Avail: No | Availability explicitly coded as "no" |
| (5) | Unclear Availability | Availability coded as "unclear" |
| (6) | Avail: Waitlist | Availability coded as "waitlist" |
| (7) | Positive Sentiment | Positive sentiment among responses |
| (8) | No. of Responses | Count of responses (number of emails + voicemails) |

Columns (1)–(7) are **binary** outcomes (linear probability model). Column (8) is a **count** outcome. For column (8), the sample conditions on having at least one response (N = 1,983), while columns (1)–(7) use the full sample (N = 5,609).

---

## Treatment Variable (Payer Domain)

The payer assignment takes three levels:

- **Private Pay** — the inquiry mentions private pay
- **Medicaid** — the inquiry mentions Medicaid
- **No Payer** — no payer information is mentioned

---

## Empirical Specification

For each outcome $Y_{ir}$ for SNF $i$ in round $r$, estimate:

$$Y_{ir} = \alpha + \tau' T_i + \gamma' X_{ir} + \lambda_r + \varepsilon_{ir}$$

### Implementation Details

The model is implemented as a **linear regression without an intercept** and with a **full set of treatment dummies** for the payer categories. This means the estimated coefficients on Private Pay, Medicaid, and No Payer are interpretable as **conditional cell means** (mean outcomes for each payer group, conditional on controls).

In practice, this is equivalent to:

```
Y_ir ~ 0 + I(Private Pay) + I(Medicaid) + I(No Payer) + [controls]
```

The reported effects (Private–Medicaid, Private–None, Medicaid–None) are **linear contrasts** (differences) of these cell means.

### Controls (Payer Domain)

The payer-domain pooled specification includes:

1. **Race assignment indicators** — dummies for White vs. Black name assignment. With the no-intercept payer dummies spanning the constant, one race dummy is collinear and dropped (Black is the omitted reference).
2. **Vignette assignment indicator** — a single binary dummy: Vignette 4 vs. Vignettes 1–3 (pooled together as the omitted reference). This is **not** a full set of vignette dummies.
3. **Day-of-week indicators** — dummies for the day of week on which the initial contact was made, with **Monday as the omitted reference**.
4. **Round fixed effects** — dummies for Pilot, Round 1, Round 2

### Standard Errors

All standard errors are **clustered at the SNF level** to account for arbitrary within-facility correlation across rounds (a facility can appear in multiple rounds).

---

## Reported Contrasts and Inference

For each outcome, the table reports:

### Cell Means
- Mean for Private Pay
- Mean for Medicaid
- Mean for No Payer

### Contrasts (Differences)
- **Private–Medicaid:** Private Pay mean minus Medicaid mean
- **Private–None:** Private Pay mean minus No Payer mean
- **Medicaid–None:** Medicaid mean minus No Payer mean

### Inference
For each contrast, the table reports:
- **Point estimate** (the difference)
- **Standard error** in parentheses `()` — SNF-clustered
- **p-value** in curly braces `{}` — two-sided Wald test
- **q-value** in square brackets `[]` — sharpened false discovery rate (Benjamini, Krieger, and Yekutieli, 2006)

### Multiple Testing Adjustment

The q-values control the false discovery rate **within the payer domain**. The set of p-values fed into the BKY procedure includes all payer contrasts (Private–Medicaid, Private–None, Medicaid–None) across **all outcomes** (8 outcomes) and **all specification panels** (pooled, Round 1, Round 2). That is, the q-values in Table 7 are jointly adjusted with those in Tables 12 and 13 (the round-specific payer tables). This yields 3 contrasts × 8 outcomes × 3 panels = 72 tests in the BKY adjustment set.

---

## Replication Checklist

To replicate Table 7, a script should:

1. Load the SNF–round-level analysis dataset.
2. Confirm N = 5,609 for binary outcomes and N = 1,983 for the count outcome (No. of Responses).
3. For each of the 8 outcomes:
   a. Regress the outcome on a no-intercept specification with payer dummies (Private Pay, Medicaid, No Payer), controlling for race assignment (White dummy, Black omitted), a binary vignette indicator (Vignette 4 vs. Vignettes 1–3), day-of-week (Monday omitted), and round fixed effects.
   b. Cluster standard errors at the SNF level.
   c. Extract the three cell means (coefficients on the payer dummies).
   d. Compute the three linear contrasts (Private–Medicaid, Private–None, Medicaid–None).
   e. Compute two-sided p-values for each contrast.
4. Collect all p-values from the payer domain (pooled + Round 1 + Round 2, all outcomes, all contrasts) and apply the BKY (2006) sharpened FDR procedure to obtain q-values.
5. Format results matching the table layout.

---

## Notes on Interpretation

- The **No Payer** cell mean equals the **Black** cell mean from the race-domain table (Table 6), because "No Payer" is the omitted/reference payer category in that specification and corresponds to the same underlying observations. This is a useful cross-check.
- The model is a **linear probability model** for binary outcomes. OLS is used throughout; no logit/probit.
- Column (8) uses OLS on the count of responses, not Poisson or negative binomial.
