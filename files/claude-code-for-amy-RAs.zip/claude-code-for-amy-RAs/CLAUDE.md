# NursingHomeAdmissions

## Project purpose

This project analyzes RCT results to detect selective admissions practices
based on payer type (e.g., Medicare vs. Medicaid vs. private-pay) in nursing
homes.  The primary analytical question is whether nursing homes systematically
admit or reject applicants differently depending on expected payer mix.

## Directory structure

```
.
├── Project.toml          # Julia package dependencies
├── Manifest.toml         # auto-generated, gitignored
├── CLAUDE.md             # this file
├── code/
│   ├── 00_setup.jl       # activate env + load packages (include at top of scripts)
│   └── ...               # analysis scripts numbered 01_, 02_, ...
├── data/
│   ├── raw/              # original data files — never modified, gitignored
│   └── processed/        # cleaned/merged data — gitignored
└── output/               # figures, tables, logs — gitignored
```

## Getting started

```julia
# From the Julia REPL, with working directory set to the project root:
using Pkg
Pkg.activate(".")
Pkg.instantiate()   # downloads all packages listed in Project.toml

# Then run the setup script to load packages and define path constants:
include("code/00_setup.jl")
```

Or launch Julia with the project already active:

```bash
julia --project=. code/00_setup.jl
```

## Key packages

| Package             | Purpose                                      |
|---------------------|----------------------------------------------|
| CSV, DataFrames     | data ingestion and wrangling                 |
| CategoricalArrays   | factor-like payer-type and facility columns  |
| GLM                 | logistic / linear regression                 |
| FixedEffectModels   | facility- or market-level fixed effects      |
| HypothesisTests     | chi-square, Fisher exact, t-tests            |
| StatsBase           | summary statistics                           |
| CairoMakie          | publication-quality vector figures           |
| StatsPlots          | statistical plot recipes                     |

## Agent usage

When dispatching agents (via superpowers skills or otherwise), always prefer the
project's custom agents over generic `general-purpose` agents:

- **`julia-coder`** — for all code writing, refactoring, and implementation tasks (this is a Julia project)
- **`data-explorer`** — for dataset profiling, EDA, missingness analysis, merge-key identification, and data quality checks

Only fall back to `general-purpose` if the task genuinely doesn't fit either agent
(e.g., pure git operations, web research with no code component).

## Coding conventions

- Scripts are numbered (`01_clean.jl`, `02_merge.jl`, `03_analysis.jl`, ...).
- Every script starts with `include(joinpath(@__DIR__, "00_setup.jl"))`.
- Use `DATA_RAW`, `DATA_PROC`, and `OUTPUT_DIR` constants (defined in `00_setup.jl`)
  rather than hard-coded paths.
- Save figures to `OUTPUT_DIR` using `CairoMakie.save`.
- Follow Julia naming conventions: `snake_case` for variables/functions,
  `PascalCase` for types.
