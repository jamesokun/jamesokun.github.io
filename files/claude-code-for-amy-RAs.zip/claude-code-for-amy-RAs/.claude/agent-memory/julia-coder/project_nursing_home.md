---
name: nursing-home-admissions-project
description: Core facts about the NursingHomeAdmissions Julia project — purpose, packages, and conventions
type: project
---

This project analyzes RCT results to detect selective admissions practices based on payer type (Medicare / Medicaid / private-pay) in nursing homes.

**Why:** Research question is whether payer mix drives differential admission decisions — the unit of observation is likely an application or applicant, with facility as a grouping variable.

**How to apply:** When writing analysis code, prefer fixed-effects models at the facility level (FixedEffectModels.jl), logistic regression for binary admission outcomes (GLM.jl), and CategoricalArrays for payer-type columns. Save all figures to `OUTPUT_DIR` via CairoMakie. Every script should start with `include("code/00_setup.jl")` to get path constants and loaded packages.

Key registered dependencies: CSV, DataFrames, CategoricalArrays, GLM, FixedEffectModels, HypothesisTests, StatsBase, CairoMakie, StatsPlots.

Path constants defined in `00_setup.jl`: `DATA_RAW`, `DATA_PROC`, `OUTPUT_DIR`.
