# Agent Memory Index

## Project

- [project_nursing_home.md](project_nursing_home.md) — NursingHomeAdmissions project purpose, packages, and coding conventions
