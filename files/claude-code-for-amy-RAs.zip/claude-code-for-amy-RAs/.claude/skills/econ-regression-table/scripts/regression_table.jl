"""
    regression_table(models; kwargs...) -> String

Generate a publication-quality LaTeX regression table from fitted Julia model objects,
following standard economics journal conventions.

# Arguments
- `models::Vector`: Fitted regression models (from GLM.jl or FixedEffectModels.jl).
  Standard errors are taken directly from each model object — to get robust SEs,
  specify `Vcov.robust()` at estimation time.

# Keyword Arguments
- `colnames::Vector{String}`: Column headers (default: `["(1)", "(2)", ...]`)
- `varnames::Dict{String,String}`: Map coefficient name → display name in table
- `keep::Vector{String}`: Which coefficients to show (by model coefname). Empty = show all.
- `fe_indicators::Vector{Pair{String,Vector{String}}}`: Fixed-effects indicator rows.
  Each pair is `"Display Label" => ["fe_var1", ...]`. Prints "Yes" if the model formula
  contains any of those variables as absorbed FEs.
- `dep_var_means::Vector{<:Real}`: Mean of dependent variable for each column
- `title::String`: Table caption
- `label::String`: LaTeX label for `\\ref{}`
- `notes::String`: Footnote text below the table
- `outpath::String`: Where to write the `.tex` file (empty = don't write)
- `digits::Int`: Decimal places for coefficients/SEs (default: 3)

# Returns
The LaTeX table as a `String`. Also writes to `outpath` if provided.
"""
function regression_table(
    models::Vector;
    colnames::Vector{String} = ["($i)" for i in 1:length(models)],
    varnames::Dict{String,String} = Dict{String,String}(),
    keep::Vector{String} = String[],
    fe_indicators::Vector{Pair{String,Vector{String}}} = Pair{String,Vector{String}}[],
    dep_var_means::Vector = [],
    title::String = "",
    label::String = "",
    notes::String = "",
    outpath::String = "",
    digits::Int = 3
)
    ncols = length(models)
    @assert ncols == length(colnames) "Number of column names must match number of models"
    if !isempty(dep_var_means)
        @assert length(dep_var_means) == ncols "dep_var_means length must match number of models"
    end

    # ── Collect coefficient names in display order ───────────────────────
    all_coefnames = String[]
    for m in models
        for cn in coefnames(m)
            cn ∉ all_coefnames && push!(all_coefnames, cn)
        end
    end
    display_coefs = isempty(keep) ? all_coefnames : filter(c -> c ∈ all_coefnames, keep)

    # ── Helpers ──────────────────────────────────────────────────────────
    fmt(x::Real) = Printf.@sprintf("%.*f", digits, x)
    fmt_int(x)   = string(Int(x))

    function get_coef_se(m, cname)
        cnames = coefnames(m)
        idx = findfirst(==(cname), cnames)
        idx === nothing && return (nothing, nothing)
        return (coef(m)[idx], stderror(m)[idx])
    end

    function model_has_fe(m, fe_vars::Vector{String})
        # FixedEffectModels stores absorbed FE keys in m.fekeys as Vector{Symbol}
        if hasproperty(m, :fekeys)
            model_fes = String.(m.fekeys)
            return any(v -> v ∈ model_fes, fe_vars)
        end
        # Fallback: check formula string (for other model types)
        try
            fe_str = string(formula(m))
            return any(v -> occursin("fe($v)", fe_str), fe_vars)
        catch
            return false
        end
    end

    # ── Build LaTeX ──────────────────────────────────────────────────────
    lines = String[]

    push!(lines, "\\begin{table}[htbp]")
    push!(lines, "\\centering")
    !isempty(title) && push!(lines, "\\caption{$title}")
    !isempty(label) && push!(lines, "\\label{$label}")

    colspec = "l" * "c"^ncols
    push!(lines, "\\begin{tabular}{$colspec}")
    push!(lines, "\\toprule")

    # Header
    push!(lines, " & " * join(colnames, " & ") * " \\\\")
    push!(lines, "\\midrule")

    # Coefficients + SEs
    for cname in display_coefs
        display_name = get(varnames, cname, replace(cname, "_" => "\\_"))

        coef_cells = String[]
        se_cells   = String[]
        for m in models
            b, se = get_coef_se(m, cname)
            if b === nothing
                push!(coef_cells, "")
                push!(se_cells, "")
            else
                push!(coef_cells, fmt(b))
                push!(se_cells, "($(fmt(se)))")
            end
        end

        push!(lines, "$(display_name) & " * join(coef_cells, " & ") * " \\\\")
        push!(lines, " & " * join(se_cells, " & ") * " \\\\")
    end

    push!(lines, "\\midrule")

    # FE indicators
    for (fe_label, fe_vars) in fe_indicators
        cells = [model_has_fe(m, fe_vars) ? "Yes" : "No" for m in models]
        push!(lines, "$(fe_label) & " * join(cells, " & ") * " \\\\")
    end

    # Dependent variable mean
    if !isempty(dep_var_means)
        cells = [fmt(μ) for μ in dep_var_means]
        push!(lines, "Dep.\\ var.\\ mean & " * join(cells, " & ") * " \\\\")
    end

    # Observations
    obs_cells = [fmt_int(nobs(m)) for m in models]
    push!(lines, "Observations & " * join(obs_cells, " & ") * " \\\\")

    push!(lines, "\\bottomrule")
    push!(lines, "\\end{tabular}")

    # Notes
    if !isempty(notes)
        push!(lines, "\\vspace{0.5em}")
        push!(lines, "\\begin{minipage}{\\textwidth}")
        push!(lines, "\\footnotesize")
        push!(lines, "\\textit{Notes:} $notes")
        push!(lines, "\\end{minipage}")
    end

    push!(lines, "\\end{table}")

    tex = join(lines, "\n")

    if !isempty(outpath)
        open(outpath, "w") do io
            write(io, tex)
        end
        @info "Table written to $outpath"
    end

    return tex
end
