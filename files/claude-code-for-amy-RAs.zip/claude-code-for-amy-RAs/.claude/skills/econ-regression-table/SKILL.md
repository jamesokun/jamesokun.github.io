---
name: econ-regression-table
description: Use when the user wants to create a regression table, format regression results for a paper, export regressions to LaTeX/tex, or make a table showing multiple specifications side by side. Covers OLS, IV, and fixed-effects models from GLM.jl and FixedEffectModels.jl. Also use when the user mentions "reg table", "results table", "coefficient table", or "estout/esttab equivalent in Julia".
---

# Economics Regression Table Formatter

Create LaTeX regression tables from fitted Julia models, following the conventions of top economics journals (AER, QJE, Econometrica, etc.).

## Table anatomy

| Element | Convention |
|---|---|
| Columns | One per regression specification, labeled (1), (2), ... |
| Coefficient rows | Point estimate on one line, robust SE in parentheses on the line below |
| Significance stars | None — omitted by design |
| Bottom panel | Fixed-effects indicators (Yes/No), dependent variable mean, observations (N) |
| LaTeX style | `booktabs` (`\toprule`, `\midrule`, `\bottomrule`) |
| Output | Standalone `.tex` file suitable for `\input{}` in a paper |

## How to use

The bundled script at `scripts/regression_table.jl` contains a ready-to-use `regression_table()` function. Include it in the user's analysis script:

```julia
include("<path-to-this-skill>/scripts/regression_table.jl")
```

Then call it with fitted model objects:

```julia
regression_table(
    [m1, m2, m3];
    varnames = Dict("treatment" => "Treatment", "age" => "Age"),
    keep = ["treatment", "age"],
    fe_indicators = ["Facility FE" => ["facility_id"], "Year FE" => ["year"]],
    dep_var_means = [mean(df.y), mean(df.y), mean(df.y)],
    title = "Effect of Treatment on Outcome",
    label = "tab:main",
    notes = "Heteroskedasticity-robust standard errors in parentheses.",
    outpath = "output/table_main.tex"
)
```

### Key arguments

- **`models`**: Vector of fitted models. SEs come from `stderror(m)`, so the user must specify robust variance at estimation time (e.g., `Vcov.robust()` in FixedEffectModels).
- **`varnames`**: Dict mapping internal coefficient names to human-readable labels.
- **`keep`**: Controls which coefficients appear and in what order. If empty, all coefficients are shown.
- **`fe_indicators`**: Each entry is `"Label" => ["var1", ...]`. The function checks whether the model's formula absorbed those variables and prints Yes/No.
- **`dep_var_means`**: One value per column.
- **`digits`**: Decimal places (default 3).

### Adapting the script

The bundled script handles the most common case. When the user needs something non-standard, copy the function into their project and modify directly rather than adding flags. Common adaptations:

- **GLM models with robust SEs**: GLM's `stderror()` gives classical SEs by default. Either (a) use `coeftable(m, vcov=HC1(m))` from CovarianceMatrices.jl to extract robust SEs, or (b) modify the function to accept a separate `se_override` vector.
- **Panel labels**: To group columns under panel headers (e.g., "Panel A: Medicare"), add a row before the relevant columns with `\multicolumn`.
- **Additional statistics**: R-squared, F-stat, etc. — add rows in the bottom panel following the same pattern as the observations row.
- **Landscape tables**: For many columns, wrap in `\begin{landscape}` (requires `lscape` package).

## LaTeX preamble requirements

The user's main `.tex` document needs:

```latex
\usepackage{booktabs}
```

## Example output

A table produced by this function looks like:

```latex
\begin{table}[htbp]
\centering
\caption{Effect of Payer Type on Admission Probability}
\label{tab:main}
\begin{tabular}{lccc}
\toprule
 & (1) & (2) & (3) \\
\midrule
Medicaid & -0.142 & -0.138 & -0.125 \\
 & (0.031) & (0.029) & (0.028) \\
Private pay & 0.087 & 0.091 & 0.078 \\
 & (0.024) & (0.023) & (0.022) \\
\midrule
Facility FE & No & Yes & Yes \\
Year FE & No & No & Yes \\
Dep.\ var.\ mean & 0.523 & 0.523 & 0.523 \\
Observations & 12480 & 12480 & 12480 \\
\bottomrule
\end{tabular}
\vspace{0.5em}
\begin{minipage}{\textwidth}
\footnotesize
\textit{Notes:} Heteroskedasticity-robust standard errors in parentheses.
\end{minipage}
\end{table}
```
